#include "../include/rosvis/robotcontrol.hpp"
#include "ui_robotcontrol.h"

RobotControl::RobotControl(QWidget *parent) :
  QDialog(parent),
  ui(new Ui::RobotControl)
{
  ui->setupUi(this);
}

RobotControl::~RobotControl()
{
  delete ui;
}
