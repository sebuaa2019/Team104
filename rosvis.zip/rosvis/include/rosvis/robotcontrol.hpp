#ifndef ROBOTCONTROL_H
#define ROBOTCONTROL_H

#include <QDialog>

namespace Ui {
class RobotControl;
}

class RobotControl : public QDialog
{
  Q_OBJECT

public:
  explicit RobotControl(QWidget *parent = 0);
  ~RobotControl();

private:
  Ui::RobotControl *ui;
};

#endif // ROBOTCONTROL_H
