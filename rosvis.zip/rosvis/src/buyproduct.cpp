#include "../include/rosvis/buyproduct.hpp"
#include "ui_buyproduct.h"
#include "../../wpb_home_apps/include/team104_shopping.h"


BuyProduct::BuyProduct(QWidget *parent) :
  QDialog(parent),
  ui(new Ui::BuyProduct)
{
  ui->setupUi(this);
}

BuyProduct::~BuyProduct()
{
  delete ui;
}

void BuyProduct::on_takeButton_clicked()
{
	change_status(2);
}
