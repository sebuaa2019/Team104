#ifndef KL_OUTLIER_H_
#define KL_OUTLIER_H_

float thredhold(float);
float filter (float ,float ,float* ,float* ,float& ,float& );

#endif 
