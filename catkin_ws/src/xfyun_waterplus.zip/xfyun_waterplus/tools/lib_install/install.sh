sudo cp ./lib/*.* /usr/lib/x86_64-linux-gnu/.

